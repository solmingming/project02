import React from 'react';

export default function GrassArtNextPage() {
  return (
    <div className="page" id="next-page">
      <div style={{ padding: '2rem', color: 'white' }}>
        <h1>다음 페이지</h1>
        <p>풀잎들이 여기까지 따라왔어요!</p>
      </div>
    </div>
  );
} 