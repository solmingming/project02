import React from 'react';
import './LandingSettings.css'; // 설정창 전용 CSS 파일을 만들어 스타일링합니다.

const LandingSettings = ({ isOpen, onClose }) => {
  if (!isOpen) {
    return null;
  }

  return (
    <div className="settings-overlay" onClick={onClose}>
      <div className="settings-panel" onClick={(e) => e.stopPropagation()}>
        <h2>Landing Page 설정</h2>
        <p>이곳에 랜딩 페이지에만 해당하는 설정 옵션들을 넣습니다.</p>
        <label>
          <input type="checkbox" /> 설정 옵션 1
        </label>
        <br />
        <label>
          <input type="range" /> 설정 옵션 2
        </label>
        <button onClick={onClose}>닫기</button>
      </div>
    </div>
  );
};

export default LandingSettings;