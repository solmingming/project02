import React, { useRef, useEffect } from 'react';
import '../../App.css';

const RiverCanvas = () => {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let width = canvas.width = canvas.offsetWidth;
    let height = canvas.height = canvas.offsetHeight;

    // Handle window resize
    const handleResize = () => {
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };
    window.addEventListener('resize', handleResize);

    // Initialize fish
    const fishCount = 4;
    const fish = [];
    for (let i = 0; i < fishCount; i++) {
      fish.push({
        x: Math.random() * width,
        y: Math.random() * height,
        speed: 30 + Math.random() * 20,
        size: 20 + Math.random() * 10,
        jump: i === 0,                  // 첫 번째 물고기만 점프
        jumpAmplitude: 30,
        jumpFrequency: 2 + Math.random(),
      });
    }

    // Initialize duckweed
    const duckweed = Array.from({ length: 5 }).map(() => ({
      x: Math.random() * width,
      y: Math.random() * height,
      r: 5 + Math.random() * 5,
    }));

    let lastTime = performance.now();
    let t = 0;

    function animate() {
      const now = performance.now();
      const dt = (now - lastTime) / 1000;
      lastTime = now;
      t += dt;

      // Clear canvas
      ctx.clearRect(0, 0, width, height);

      // Draw water background and waves
      drawWater();

      // Draw duckweed
      duckweed.forEach(d => {
        ctx.fillStyle = '#6B8E23';
        ctx.beginPath();
        ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
        ctx.fill();
      });

      // Update and draw fish
      fish.forEach((f, idx) => {
        f.x += f.speed * dt;
        if (f.x - f.size > width) f.x = -f.size;

        let fy = f.y;
        if (f.jump) {
          fy = f.y - Math.abs(Math.sin(t * f.jumpFrequency)) * f.jumpAmplitude;
        }
        drawFish(f.x, fy, f.size, idx === 0);
      });

      requestAnimationFrame(animate);
    }

    function drawWater() {
      const waveHeight = 20;
      const waveLength = 100;

      // Water base
      ctx.fillStyle = '#87CEEB';
      ctx.fillRect(0, 0, width, height);

      // Overlay wave lines
      ctx.strokeStyle = '#ADD8E6';
      ctx.lineWidth = 2;
      ctx.beginPath();
      for (let x = 0; x <= width; x += 10) {
        const y = height / 2 + Math.sin((x / waveLength + t) * 2 * Math.PI) * waveHeight;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
    }

    function drawFish(x, y, size, isJumpingFish) {
      ctx.save();
      ctx.translate(x, y);
      if (!isJumpingFish) ctx.scale(-1, 1); // 나머지 물고기는 반대 방향

      // Body
      ctx.fillStyle = '#FF4500';
      ctx.beginPath();
      ctx.ellipse(0, 0, size, size / 2, 0, 0, 2 * Math.PI);
      ctx.fill();

      // Tail
      ctx.beginPath();
      ctx.moveTo(-size, 0);
      ctx.lineTo(-size - size / 2, size / 2);
      ctx.lineTo(-size - size / 2, -size / 2);
      ctx.closePath();
      ctx.fill();

      ctx.restore();
    }

    // Start animation
    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      style={{ width: '100%', height: '400px', display: 'block' }}
    />
  );
};

export default RiverCanvas;