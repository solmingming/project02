import React, { useRef, useEffect, useState } from 'react';

const FlowerPage = () => {
  const audioRef = useRef(null);
  const [isMuted, setIsMuted] = useState(true);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.muted = isMuted;
      audioRef.current.play().catch(err => {
        console.warn("자동 재생 실패:", err);
      });
    }
  }, [isMuted]);

  const toggleMute = () => {
    setIsMuted(prev => !prev);
  };

  return (
    <div style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
      background: 'linear-gradient(to bottom, #CBFFBA, #FEE8FF)',
      overflow: 'hidden',
      position: 'relative'
    }}>
      <audio
        ref={audioRef}
        src="/assets/music/flower_back.mp3"
        autoPlay
        loop
      />
      
      <img 
        src="/assets/images/MainFlower.png" 
        alt="Main Flower"
        style={{
          width: '90%',
          height: '90%',
          objectFit: 'contain'
        }}
      />

      {/* 음소거 토글 버튼 */}
      <button
        onClick={toggleMute}
        style={{
          position: 'absolute',
          bottom: '30px',
          right: '30px',
          padding: '10px 20px',
          fontSize: '16px',
          borderRadius: '8px',
          background: '#fff',
          cursor: 'pointer',
          border: '1px solid #aaa'
        }}
      >
        {isMuted ? '🔇 소리 켜기' : '🔊 소리 끄기'}
      </button>
    </div>
  );
};

export default FlowerPage;
